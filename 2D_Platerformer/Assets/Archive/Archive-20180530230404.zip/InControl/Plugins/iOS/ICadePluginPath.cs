﻿namespace InControl
{
	using UnityEngine;


	// This file exists only so the build post processor can easily
	// find the iOS Xcode plugin files at the same path.
	public class ICadePluginPath : ScriptableObject
	{
	}
}

