﻿namespace InControl
{
	public interface IUpdateable
	{
		void Update( ulong updateTick, float deltaTime );
	}
}

